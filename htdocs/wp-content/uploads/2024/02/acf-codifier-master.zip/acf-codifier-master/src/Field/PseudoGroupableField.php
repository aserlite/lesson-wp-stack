<?php
/**
 * PseudoGroupableField interface
 */

namespace Geniem\ACF\Field;

/**
 * Interface class PseudoGroupableField
 */
interface PseudoGroupableField {
}

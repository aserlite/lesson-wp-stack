<?php
/**
 * Exception class for the ACF Codifier.
 */

namespace Geniem\ACF;

/**
 * Class Exception
 */
class Exception extends \Exception {}

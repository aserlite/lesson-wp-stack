Chronopost
==========

Contributors: chronopost
Donate link: https://www.adexos.fr
Tags: shipping, delivery
Requires at least: 4.0
Requires PHP: 5.6
Tested up to: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Description
-----------

Chronopost for woocommerce

Installation
------------

This section describes how to install the plugin and get it working.

1. Download the plugin from https://www.chronopost.fr/fr/plateformes-e-commerce
2. Upload the plugin to wp-content/plugins/
3. Activate the plugin in the plugins menu
4. Go to the settings page and configure the plugin
5. Test the plugin by creating a new order
6. If everything is ok, you should see the shipping method in the order page

Frequently Asked Questions
--------------------------

Nothing here yet

Change Log
----------

### 2.0.0
Refactoring to use the new shipping method API

### 1.0.3
Fix new affectation of the shipping methods
